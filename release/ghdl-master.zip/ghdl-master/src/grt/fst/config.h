/* config.h for fst.  */
#define HAVE_FSEEKO 1
