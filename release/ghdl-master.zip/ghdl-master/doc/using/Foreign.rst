.. program:: ghdl

.. _USING:Foreign:

Co-simulation
#############

See :ref:`COSIM`.
