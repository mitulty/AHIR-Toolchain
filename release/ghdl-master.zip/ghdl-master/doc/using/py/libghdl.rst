.. _python_interface:

Python Interface
################

.. automodule:: libghdl

.. toctree::
   :hidden:

   thin
   vhdl
   pyutils
