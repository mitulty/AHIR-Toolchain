#! /bin/sh

. ../../testenv.sh

analyze tb.vhdl
clean

echo "Test successful"
