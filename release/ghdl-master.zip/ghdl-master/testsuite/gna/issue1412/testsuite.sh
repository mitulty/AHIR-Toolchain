#! /bin/sh

. ../../testenv.sh

analyze_failure repro.vhdl

echo "Test successful"
