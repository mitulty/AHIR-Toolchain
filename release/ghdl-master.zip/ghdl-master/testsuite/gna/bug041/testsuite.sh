#! /bin/sh

. ../../testenv.sh

analyze_failure foo.vhdl

clean

echo "Test successful"
