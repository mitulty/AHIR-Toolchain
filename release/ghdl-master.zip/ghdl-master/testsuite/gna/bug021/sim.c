
#include <stdio.h>


void street(int number)
{
   printf("street: %d\n",number);
}        


void house(int number)
{
   printf("house: %d\n",number);
}        

