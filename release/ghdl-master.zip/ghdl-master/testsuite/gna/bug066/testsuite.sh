#! /bin/sh

. ../../testenv.sh

analyze repro.vhdl

clean

echo "Test successful"
