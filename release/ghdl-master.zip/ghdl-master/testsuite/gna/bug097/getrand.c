#include <stdlib.h>

int
get_rand (void)
{
  return rand();
}
