#! /bin/sh

. ../../testenv.sh

analyze_failure case16.vhdl

clean

echo "Test successful"
