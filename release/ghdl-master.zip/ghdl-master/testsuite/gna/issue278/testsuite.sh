#! /bin/sh

. ../../testenv.sh

analyze_failure ram_lut.vhdl

clean

echo "Test successful"
