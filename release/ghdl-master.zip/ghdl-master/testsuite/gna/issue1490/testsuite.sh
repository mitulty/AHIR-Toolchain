#! /bin/sh

. ../../testenv.sh

analyze_failure ent.vhdl

clean

echo "Test successful"
