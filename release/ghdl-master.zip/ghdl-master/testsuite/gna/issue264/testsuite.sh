#! /bin/sh

. ../../testenv.sh

analyze_failure ex1_top.vhdl

echo "Test successful"
