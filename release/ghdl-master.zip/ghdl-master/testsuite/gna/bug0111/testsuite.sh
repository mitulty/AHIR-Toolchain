#! /bin/sh

. ../../testenv.sh

analyze_failure err.vhdl

clean

echo "Test successful"
