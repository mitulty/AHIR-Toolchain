#! /bin/sh

. ../../testenv.sh

analyze_failure tb_thingy1.vhdl

clean

echo "Test successful"
