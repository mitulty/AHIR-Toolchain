from libghdl import libghdl

Install_Handler = libghdl.errorout__console__install_handler
